require 'test_helper'

class KeyResultTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
