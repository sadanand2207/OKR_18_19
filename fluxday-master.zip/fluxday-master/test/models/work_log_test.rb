require 'test_helper'

class WorkLogTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
