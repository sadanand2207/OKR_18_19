require 'test_helper'

class TaskAssigneeTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
