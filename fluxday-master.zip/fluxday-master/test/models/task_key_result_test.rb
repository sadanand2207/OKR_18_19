require 'test_helper'

class TaskKeyResultTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
