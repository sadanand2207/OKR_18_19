require 'test_helper'

class OauthApplicationsHelperTest < ActionView::TestCase
end
