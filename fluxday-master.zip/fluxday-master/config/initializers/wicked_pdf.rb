# place wkhtmltopdf executable in lib folder to generate pdf reports
WickedPdf.config = {
  :exe_path => "#{::Rails.root}/lib/wkhtmltopdf"
}

