# Load the Rails application.
require File.expand_path('../application', __FILE__)
require './lib/time_to_diff.rb'

# Initialize the Rails application.
Fluxday::Application.initialize!
