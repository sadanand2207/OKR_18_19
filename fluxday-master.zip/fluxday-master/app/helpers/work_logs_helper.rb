module WorkLogsHelper
end
