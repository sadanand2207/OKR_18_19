module KeyResultsHelper
end
